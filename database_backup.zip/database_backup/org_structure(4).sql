-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 21, 2018 at 04:43 AM
-- Server version: 5.5.57
-- PHP Version: 7.0.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vvf_pmsstructure`
--

-- --------------------------------------------------------

--
-- Table structure for table `org_structure`
--

CREATE TABLE `org_structure` (
  `Cadre` varchar(25) NOT NULL,
  `Designation` varchar(50) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Sub_designation_id` varchar(100) DEFAULT NULL,
  `Designation_id` varchar(100) NOT NULL,
  `Sub_designation_name` varchar(100) DEFAULT NULL,
  `Department` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `org_structure`
--

INSERT INTO `org_structure` (`Cadre`, `Designation`, `Name`, `Sub_designation_id`, `Designation_id`, `Sub_designation_name`, `Department`) VALUES
('A', 'Sales Executive', 'Someone', NULL, '1', NULL, 'Sales'),
('B', 'Executive', 'Some', NULL, '2', 'dsfds', 'Purchase');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `org_structure`
--
ALTER TABLE `org_structure`
  ADD PRIMARY KEY (`Designation_id`),
  ADD UNIQUE KEY `Sub_designation_id_UNIQUE` (`Sub_designation_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
