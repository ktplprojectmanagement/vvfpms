-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 21, 2018 at 04:43 AM
-- Server version: 5.5.57
-- PHP Version: 7.0.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vvf_pmsstructure`
--

-- --------------------------------------------------------

--
-- Table structure for table `program_data`
--

CREATE TABLE `program_data` (
  `id` int(11) NOT NULL,
  `program_name` varchar(300) NOT NULL,
  `faculty_type` varchar(100) NOT NULL,
  `amount` float NOT NULL,
  `faculty_email_id` varchar(100) NOT NULL,
  `training_days` float NOT NULL,
  `faculty_name` varchar(100) NOT NULL,
  `external_name` varchar(100) NOT NULL,
  `need` int(11) NOT NULL,
  `location` varchar(100) NOT NULL,
  `goal_set_year` varchar(1000) NOT NULL,
  `Note` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `program_data`
--

INSERT INTO `program_data` (`id`, `program_name`, `faculty_type`, `amount`, `faculty_email_id`, `training_days`, `faculty_name`, `external_name`, `need`, `location`, `goal_set_year`, `Note`) VALUES
(4, 'Effective Communication Skills', 'Internal', 0, 'prasanna.sp@vvfltd.com', 1, 'Prasanna Purushothaman', '', 0, 'Corporate;Sion;Sewree;Taloja;Baddi;Daman', '2017-2018', ''),
(16, 'Getting Things Done', 'Internal', 0, 'prasanna.sp@vvfltd.com', 1, 'Prasanna Purushothaman', '', 0, 'Corporate;Sion;Sewree;Taloja;Baddi;Tiljala;Daman', '2017-2018', ''),
(17, 'Environment Health and Safety', 'Internal', 0, 'sunil.katekari@vvfltd.com', 1, 'Sunil Katekari', '', 1, '', '2017-2018', ''),
(18, 'Training on ISO 9001 & 15000', 'Internal', 0, 'ashokrao.patil@vvfltd.com', 1, 'ASHOKRAO PATIL', '', 2, '', '2017-2018', ''),
(19, 'Good Manufacturing Practices  (GMP +) and cGMP', 'Internal', 0, 'ashokrao.patil@vvfltd.com', 0.5, 'ASHOKRAO PATIL', '', 2, 'Corporate;Taloja;Baddi;Daman', '2016-2017', ''),
(21, 'The Super Manager', 'Internal', 0, 'amit.sanas@vvfltd.com', 2, 'Amit Sanas', '', 0, '', '2017-2018', 'None'),
(22, 'Six Thinking Hats', 'External', 10000, '', 1, '', 'TBD', 0, '', '2017-2018', ''),
(23, 'Art of Charm ', 'Internal', 0, 'anant.pednekar@vvfltd.com', 1, 'Anant Pednekar', '', 0, '', '2017-2018', ''),
(24, 'Prevention of Sexual Harassment', 'External', 0, '', 1, '', 'TBD', 1, '', '2017-2018', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `program_data`
--
ALTER TABLE `program_data`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `program_data`
--
ALTER TABLE `program_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
