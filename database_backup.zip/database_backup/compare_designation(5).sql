-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 21, 2018 at 04:39 AM
-- Server version: 5.5.57
-- PHP Version: 7.0.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vvf_pmsstructure`
--

-- --------------------------------------------------------

--
-- Table structure for table `compare_designation`
--

CREATE TABLE `compare_designation` (
  `designation` varchar(100) NOT NULL,
  `flag` int(100) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `compare_designation`
--

INSERT INTO `compare_designation` (`designation`, `flag`, `id`) VALUES
('Assistant Manager', 0, 2),
('Executive', 0, 3),
('Junior Executive', 0, 4),
('Manager', 0, 5),
('Regional Sales Manager', 0, 6),
('Senior Manager', 0, 7),
('Assistant General Manager', 1, 8),
('Deputy General Manager', 1, 9),
('Associate Vice President', 1, 10),
('Business Head-Contract Manufacturing Business', 1, 11),
('CHIEF FINANCIAL OFFICER', 1, 12),
('Director & President', 1, 13),
('Executive Chairman', 1, 14),
('General Manager', 1, 15),
('JOINT MANAGING DIRECTOR', 1, 16),
('Managing Director ', 1, 17),
('Senior Vice President', 1, 18),
('Vice President', 1, 19);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `compare_designation`
--
ALTER TABLE `compare_designation`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `compare_designation`
--
ALTER TABLE `compare_designation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
