-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 21, 2018 at 04:39 AM
-- Server version: 5.5.57
-- PHP Version: 7.0.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vvf_pmsstructure`
--

-- --------------------------------------------------------

--
-- Table structure for table `cluster`
--

CREATE TABLE `cluster` (
  `id` int(11) NOT NULL,
  `cluster_name` varchar(100) NOT NULL,
  `department` varchar(1000) NOT NULL,
  `grade` text NOT NULL,
  `cluster_appraiser` text NOT NULL,
  `designation` text NOT NULL,
  `headname` varchar(100) NOT NULL,
  `clusterhead_name` varchar(100) NOT NULL,
  `Reporting_officer1_id` varchar(100) NOT NULL,
  `BU` varchar(1000) NOT NULL,
  `company_location` varchar(1000) NOT NULL,
  `Designation1` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cluster`
--

INSERT INTO `cluster` (`id`, `cluster_name`, `department`, `grade`, `cluster_appraiser`, `designation`, `headname`, `clusterhead_name`, `Reporting_officer1_id`, `BU`, `company_location`, `Designation1`) VALUES
(390, 'R&D', 'Research & Development;Quality Control', 'A;A1;A2;A3;D;EG;EG-0;EG-1;EG-2;EG-3;EG-4;EG-5;EG-6;EG-7;EG-8;EG-9;EG-10;EG-11;EG-12;EG-13;GET;HSK;J1;J2;J3;M-0;M1;M2;MT;S1;S2;SG;SK;SSK;T1;T2;TR;USK', 'demo.appraisel@gmail.com', 'Assistant Manager^Junior Executive^Manager^Executive;Senior Manager^Assistant General Manager^Deputy;General Manager^Vice President^Chief Financial Officer^Director & President^Associate Vice President^Joint Managing Director^Chairman^Senior Vice President^Managing Director^Sr. Vice President', 'sdf', 'Amarjit Mishra', '', 'Corporate Shared Services;Oleochemicals;Consumer Products Division;Contract Manufacturing;Personal Care Products;SMC;CSS;PCP', 'Corporate;Sion;Taloja;Raipur;Kolkata;Baddi;Tiljala;Kutch-II;Palanpur;Daman;Chennai;New Delhi;Taloja', 'Assistant Manager;Junior Executive;Senior Manager;Executive;Manager;Assistant General Manager;General Manager;Vice President;Deputy General Manager;CHIEF FINANCIAL OFFICER;Director & President;Associate Vice President;JOINT MANAGING DIRECTOR;Executive Chairman;Senior Vice President;Managing Director;Regional Sales Manager;Business Head-Contract Manufacturing Business;Consultant'),
(391, 'Oleo Non Mfg', 'Engineering Services;Quality Control;Sales & Marketing;Quality Assurance;Projects;Stores;Environment;Health & Safety;Dispatch;Supply Chain Management;Business Finance;Production;Technical Services', '', 'khushroo.forbes@vvfltd.com', '', '', 'Khushroo Forbes', '', '', '', ''),
(392, 'Oleo Mfg', 'Mechanical;Production;HYDROGENATION;SPLITTING;Instrumentation;Fabrication;TANKFARM;FATTY ALCOHOL;DRU;Engineering Services;Production;Utility;Distillation', '', 'employee.kritva@gmail.com', '', '', 'Sunil Singh', '', '', '', ''),
(393, 'HR/Security/Admin', 'Security Administration;Human Resources;Administration;Sewree Operation', '', 'amit.sanas@vvfltd.com', '', '', 'Mohit Sharma', '', '', '', ''),
(394, 'Finance / IT / Indirect Tax/Excise/EXIM', 'Excise;EXIM;Information Technology;Finance & Accounts;ACCOUNTS;Commercial;Imports', '', 'amarjit.mishra@vvfltd.com', '', '', 'Gajendra Palo', '', '', '', ''),
(395, 'SMC Cluster', 'Security Administration;QUALITY CONTROL;Sales & Marketing;Finance & Accounts;Legal & Secretarial;COR', '', '', '', '', '', '', '', '', ''),
(396, 'Strategic Procurement', 'Strategic Procurement;Engineering Purchase;Logistics;Operations', '', '', '', '', '', '', '', '', ''),
(397, 'Miscellaneous', 'Sales;CMD\'s Office;Sales & Marketing;Marketing;Legal & Secretarial;CMD Office', '', '', '', '', '', '', '', '', ''),
(398, 'CMB Non Mfg', 'PCP-Corporate;PCP-Business Finance;Strategic Procurement;Sales & Marketing;Quality Assurance;Stores;', '', '', '', '', '', '', '', '', ''),
(399, 'CMB Mfg', 'Production;Engineering Services;Talcum Powder;Finished Soap;Electrical;Quality Control;Mechanical;Ma', '', '', '', '', '', '', '', '', ''),
(400, 'CMB Manufacturing', 'Operations', '', '', '', '', '', '', '', '', ''),
(401, 'Sewree Operations', 'Sewree Operations', '', '', '', '', '', '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cluster`
--
ALTER TABLE `cluster`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cluster`
--
ALTER TABLE `cluster`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=402;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
