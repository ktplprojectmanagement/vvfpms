-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 21, 2018 at 04:44 AM
-- Server version: 5.5.57
-- PHP Version: 7.0.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vvf_pmsstructure`
--

-- --------------------------------------------------------

--
-- Table structure for table `report_format`
--

CREATE TABLE `report_format` (
  `id` int(11) NOT NULL,
  `content_list` varchar(300) NOT NULL,
  `report_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `report_format`
--

INSERT INTO `report_format` (`id`, `content_list`, `report_name`) VALUES
(3, 'Employee_id;Employee_atd_code;Emp_fname;Emp_mname', 'Table'),
(16, 'Employee_id;Employee_atd_code;Emp_fname', 'Demo'),
(17, 'Employee_id;Employee_atd_code;Emp_fname;Emp_mname;Emp_lname;Gender;DOB;Nationality;Email_id;mobile_number', 'first '),
(18, 'Employee_id;Emp_fname;Emp_lname;Designation;Cadre;Reporting_officer1_id;joining_date;cluster_appraiser;cluster_name;company_location', 'demo');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `report_format`
--
ALTER TABLE `report_format`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `report_format`
--
ALTER TABLE `report_format`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
