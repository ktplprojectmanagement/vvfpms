-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 21, 2018 at 04:42 AM
-- Server version: 5.5.57
-- PHP Version: 7.0.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vvf_pmsstructure`
--

-- --------------------------------------------------------

--
-- Table structure for table `KRA_structure`
--

CREATE TABLE `KRA_structure` (
  `KRA_id` varchar(100) NOT NULL,
  `No_of_KPI` int(11) NOT NULL,
  `Weightage` float NOT NULL,
  `KRP_wt_format` varchar(50) NOT NULL,
  `applicable_to` varchar(100) NOT NULL,
  `KRA_creation_date` varchar(50) NOT NULL,
  `KRA_hide_date` varchar(50) NOT NULL,
  `KRA_category` varchar(100) NOT NULL,
  `id` int(11) NOT NULL,
  `KRA_submission_date` date NOT NULL,
  `minimum_kpi` int(11) NOT NULL,
  `maximum_kpi` int(11) NOT NULL,
  `KPI_target_value` varchar(100) NOT NULL,
  `kra_assign_flag` int(11) NOT NULL,
  `Cadre` varchar(1000) NOT NULL,
  `TargetList` varchar(100) NOT NULL,
  `min_kpi_wt` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `KRA_structure`
--

INSERT INTO `KRA_structure` (`KRA_id`, `No_of_KPI`, `Weightage`, `KRP_wt_format`, `applicable_to`, `KRA_creation_date`, `KRA_hide_date`, `KRA_category`, `id`, `KRA_submission_date`, `minimum_kpi`, `maximum_kpi`, `KPI_target_value`, `kra_assign_flag`, `Cadre`, `TargetList`, `min_kpi_wt`) VALUES
('', 0, 0, '', '', '', '', '--Select--', 70, '0000-00-00', 0, 0, '', 0, '', '', ''),
('57e1213a17c4c', 5, 0, '', '', '2016-09-20', '', 'People', 71, '0000-00-00', 2, 10, '', 1, 'SMC', 'Target1;Target2;Target3;Target4;Target5', '10'),
('57e1212e7ae8a', 5, 0, '', '', '2016-09-20', '', 'Customer', 72, '0000-00-00', 2, 10, '', 1, 'SMC', 'Target1;Target2;Target3;Target4;Target5', '10'),
('57e120ed7c81f', 5, 0, '', '', '2016-09-20', '', 'Business', 73, '0000-00-00', 2, 10, '', 1, 'SMC', 'Target1;Target2;Target3;Target4;Target5', '10'),
('57eba210c4f08', 5, 0, '', '', '2016-09-28', '', 'Process', 75, '0000-00-00', 2, 10, '', 1, 'SMC', 'Target1;Target2;Target3;Target4;Target5', '10');

--
-- Triggers `KRA_structure`
--
DELIMITER $$
CREATE TRIGGER `kra_delete` AFTER DELETE ON `KRA_structure` FOR EACH ROW BEGIN
    INSERT INTO kra_backup (KRA_id, No_of_KPI,Weightage,KRP_wt_format,	applicable_to,KRA_creation_date,KRA_hide_date,KRA_category,minimum_kpi,	maximum_kpi,KPI_target_value,changes_date) VALUES (OLD.KRA_id, OLD.No_of_KPI, OLD.Weightage, OLD.KRP_wt_format, OLD.applicable_to, OLD.KRA_creation_date, OLD.KRA_hide_date, OLD.KRA_category, OLD.minimum_kpi, OLD.maximum_kpi, OLD.KPI_target_value,CURRENT_TIMESTAMP);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `kra_update` BEFORE UPDATE ON `KRA_structure` FOR EACH ROW BEGIN
    INSERT INTO kra_backup (KRA_id, No_of_KPI,Weightage,KRP_wt_format,	applicable_to,KRA_creation_date,KRA_hide_date,KRA_category,minimum_kpi,	maximum_kpi,KPI_target_value,changes_date) VALUES (OLD.KRA_id, OLD.No_of_KPI, OLD.Weightage, OLD.KRP_wt_format, OLD.applicable_to, OLD.KRA_creation_date, OLD.KRA_hide_date, OLD.KRA_category, OLD.minimum_kpi, OLD.maximum_kpi, OLD.KPI_target_value,CURRENT_TIMESTAMP);
END
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `KRA_structure`
--
ALTER TABLE `KRA_structure`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `KRA_structure`
--
ALTER TABLE `KRA_structure`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
