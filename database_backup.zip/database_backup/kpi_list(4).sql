-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 21, 2018 at 04:42 AM
-- Server version: 5.5.57
-- PHP Version: 7.0.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vvf_pmsstructure`
--

-- --------------------------------------------------------

--
-- Table structure for table `kpi_list`
--

CREATE TABLE `kpi_list` (
  `kpi_name` varchar(100) NOT NULL,
  `kpi_description` varchar(300) NOT NULL,
  `department` varchar(50) NOT NULL,
  `KPI_creation_date` date NOT NULL,
  `KPI_id` varchar(100) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kpi_list`
--

INSERT INTO `kpi_list` (`kpi_name`, `kpi_description`, `department`, `KPI_creation_date`, `KPI_id`, `id`) VALUES
('sales for mumbai', 'Mumbai gross sales', 'R&D', '2016-09-21', '57e22db9d9e22', 5),
('Finance Data', 'Finance', 'Finance', '2016-09-01', '222', 6),
('new', 'fghgfh', 'R&D', '2016-09-21', '57e2803daa07c', 9),
('Sales for North Region', 'Sales for North Region', 'R&D', '2016-09-29', '57ece57fce9a4', 10);

--
-- Triggers `kpi_list`
--
DELIMITER $$
CREATE TRIGGER `AFTER_KPI_delete` AFTER DELETE ON `kpi_list` FOR EACH ROW INSERT INTO kpi_backup (kpi_name, kpi_description,department,changes_date) VALUES (OLD.kpi_name, OLD.kpi_description, OLD.department,CURRENT_TIMESTAMP)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `before_employee_update` BEFORE UPDATE ON `kpi_list` FOR EACH ROW BEGIN
    INSERT INTO kpi_backup (kpi_name, kpi_description,department,KPI_creation_date,changes_date) VALUES (OLD.kpi_name, OLD.kpi_description, OLD.department, OLD.KPI_creation_date,CURRENT_TIMESTAMP);
END
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kpi_list`
--
ALTER TABLE `kpi_list`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kpi_list`
--
ALTER TABLE `kpi_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
