-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 21, 2018 at 04:44 AM
-- Server version: 5.5.57
-- PHP Version: 7.0.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vvf_pmsstructure`
--

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `setting_content` varchar(100) NOT NULL,
  `setting_type` varchar(50) NOT NULL,
  `year` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `setting_content`, `setting_type`, `year`) VALUES
(43, 'goal_sub_date', '2018-Mar-24', 2018),
(44, 'mid_goal_set_tab_active-date', '2018-Mar-30', 2018),
(45, 'emp_id-Automatic', 'prefix_emp_id-vvf;postfix_emp_id-', 2018),
(46, 'emp_atd_code-Automatic', 'prefix_emp_atd_code-vvf;postfix_emp_atd_code-', 2018),
(47, 'final_goal_set_tab_active', '0', 2018),
(48, 'final_goal_set_tab_active-date', '2018-Apr-30', 2018),
(49, 'PMS_display_format', '2017-2018', 2018),
(50, 'mid_goal_set_tab_active', '0', 2018),
(51, 'goal_set_tab_active', '1', 2018),
(52, 'norm_active-date', '2017-May-30', 2018),
(53, 'promo_active-date', '2017-Jun-30', 2018),
(54, 'dis_active-date', '2018-Apr-23', 2018),
(55, 'norm_set_tab_active', '0', 2018);

--
-- Triggers `settings`
--
DELIMITER $$
CREATE TRIGGER `setting_delete` AFTER DELETE ON `settings` FOR EACH ROW BEGIN
    INSERT INTO setting_backup (setting_content, setting_type,year,changes_date) VALUES (OLD.setting_content, OLD.setting_type, OLD.year,CURRENT_TIMESTAMP);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `setting_update` BEFORE UPDATE ON `settings` FOR EACH ROW BEGIN
    INSERT INTO setting_backup (setting_content, setting_type,year,changes_date) VALUES (OLD.setting_content, OLD.setting_type, OLD.year,CURRENT_TIMESTAMP);
END
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
