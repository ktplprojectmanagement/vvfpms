-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 21, 2018 at 04:41 AM
-- Server version: 5.5.57
-- PHP Version: 7.0.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vvf_pmsstructure`
--

-- --------------------------------------------------------

--
-- Table structure for table `Employee_master2`
--

CREATE TABLE `Employee_master2` (
  `Emp_fname` text NOT NULL,
  `Emp_lname` text NOT NULL,
  `id` int(11) NOT NULL,
  `Emp_mname` text NOT NULL,
  `email` text NOT NULL,
  `Permanent_address` text NOT NULL,
  `Pincode` text NOT NULL,
  `Basic_qualification` text NOT NULL,
  `Post_graduations` text NOT NULL,
  `Pan_number` text NOT NULL,
  `aadhar_no` text NOT NULL,
  `dob` text NOT NULL,
  `Age_yrs` text NOT NULL,
  `Age_months` text NOT NULL,
  `state` text NOT NULL,
  `city` text NOT NULL,
  `Marital_status` text NOT NULL,
  `No_of_dependents` text NOT NULL,
  `Blood_group` text NOT NULL,
  `Gender` text NOT NULL,
  `Additional_qualification` text NOT NULL,
  `Employee_id` text NOT NULL,
  `Old_Employee_ID` text NOT NULL,
  `Position_code` text NOT NULL,
  `Designation` text NOT NULL,
  `Department` text NOT NULL,
  `Sub_department` text NOT NULL,
  `BU` text NOT NULL,
  `Cadre` text NOT NULL,
  `Grade` text NOT NULL,
  `company_location` text NOT NULL,
  `Location_payroll_at` text NOT NULL,
  `cluster_name` text NOT NULL,
  `Reporting_Mgr_SAP_Code` text NOT NULL,
  `Reporting_1_for_time_n_attendance` text NOT NULL,
  `Reporting_1_for_appraisal` text NOT NULL,
  `Reporting_officer2_id` text NOT NULL,
  `Manager_manager` text NOT NULL,
  `cluster_appraiser` text NOT NULL,
  `Types_of_trainee` text NOT NULL,
  `Department_on_joining` text NOT NULL,
  `Date_of_Training_to_confirmation` text NOT NULL,
  `Actual_date_of_probation_to_Confirmation` text NOT NULL,
  `After_trainee_confirmed_as_wef` text NOT NULL,
  `Previous_employer` text NOT NULL,
  `joining_date` text NOT NULL,
  `Other_exp` text NOT NULL,
  `VVF_exp` text NOT NULL,
  `Total_exp` text NOT NULL,
  `Due_date_for_training_to_probation` text NOT NULL,
  `Actual_date_for_training_to_probation` text NOT NULL,
  `Confirmation_due_date` text NOT NULL,
  `Confirmation_extention_date` text NOT NULL,
  `Confirmation_actual_date` text NOT NULL,
  `Promotion_date` text NOT NULL,
  `Designation_before_promotion` text NOT NULL,
  `Cadre_before_promotion` text NOT NULL,
  `Previous_grade` text NOT NULL,
  `Redesignation_date` text NOT NULL,
  `desig_bfr_redesgn` text NOT NULL,
  `cadre_before_redesignation` text NOT NULL,
  `Grade_before_redesignation_grade` text NOT NULL,
  `Designation_bef_promo_icgc` text NOT NULL,
  `Transferred_from_loc` text NOT NULL,
  `Transfer_wef_loc` text NOT NULL,
  `Transferred_from_old_data` text NOT NULL,
  `Transfer_old_data_wef_loc` text NOT NULL,
  `Transferred_from_dept` text NOT NULL,
  `Transfer_wef_dept` text NOT NULL,
  `retire_date` text NOT NULL,
  `last_working_date` text NOT NULL,
  `Attrition_period` text NOT NULL,
  `Date_of_resignation` text NOT NULL,
  `Reason_for_leaving` text NOT NULL,
  `Exit_category` text NOT NULL,
  `Remarks` text NOT NULL,
  `Type_of_attrition` text NOT NULL,
  `Cost_centre_codes` text NOT NULL,
  `Cost_centre_description` text NOT NULL,
  `Employee_status` text NOT NULL,
  `u_id` text NOT NULL,
  `contact` text NOT NULL,
  `comp_name` text NOT NULL,
  `personal_email` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Employee_master2`
--

INSERT INTO `Employee_master2` (`Emp_fname`, `Emp_lname`, `id`, `Emp_mname`, `email`, `Permanent_address`, `Pincode`, `Basic_qualification`, `Post_graduations`, `Pan_number`, `aadhar_no`, `dob`, `Age_yrs`, `Age_months`, `state`, `city`, `Marital_status`, `No_of_dependents`, `Blood_group`, `Gender`, `Additional_qualification`, `Employee_id`, `Old_Employee_ID`, `Position_code`, `Designation`, `Department`, `Sub_department`, `BU`, `Cadre`, `Grade`, `company_location`, `Location_payroll_at`, `cluster_name`, `Reporting_Mgr_SAP_Code`, `Reporting_1_for_time_n_attendance`, `Reporting_1_for_appraisal`, `Reporting_officer2_id`, `Manager_manager`, `cluster_appraiser`, `Types_of_trainee`, `Department_on_joining`, `Date_of_Training_to_confirmation`, `Actual_date_of_probation_to_Confirmation`, `After_trainee_confirmed_as_wef`, `Previous_employer`, `joining_date`, `Other_exp`, `VVF_exp`, `Total_exp`, `Due_date_for_training_to_probation`, `Actual_date_for_training_to_probation`, `Confirmation_due_date`, `Confirmation_extention_date`, `Confirmation_actual_date`, `Promotion_date`, `Designation_before_promotion`, `Cadre_before_promotion`, `Previous_grade`, `Redesignation_date`, `desig_bfr_redesgn`, `cadre_before_redesignation`, `Grade_before_redesignation_grade`, `Designation_bef_promo_icgc`, `Transferred_from_loc`, `Transfer_wef_loc`, `Transferred_from_old_data`, `Transfer_old_data_wef_loc`, `Transferred_from_dept`, `Transfer_wef_dept`, `retire_date`, `last_working_date`, `Attrition_period`, `Date_of_resignation`, `Reason_for_leaving`, `Exit_category`, `Remarks`, `Type_of_attrition`, `Cost_centre_codes`, `Cost_centre_description`, `Employee_status`, `u_id`, `contact`, `comp_name`, `personal_email`) VALUES
('gita', 'kapoor', 66, '', 'geeta.kapoor@vvf.com', 'Mumbai', '852369', 'BA', '', 'ASDFG5678S', '555555555555', '07-02-1974', '43 Years', ' 7 months 20 days', 'Maharashtra', 'Mumbai', 'Single', '2', 'B -ve', 'Female', '', '', '', '', '', '', '', '', '', '', 'taloja', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '59cc99b58eb51', '9865321245', 'VVF Ltd.', 'geeta.kapoor@gmail.com'),
('Vaibhav', 'Savate', 79, 'P', 'vaibhav@vvfltd.co.im', 'Karm Resi, Belapur', '658100', 'BE E&TC', '', 'UJHYI4852P', '810056124554', '25-10-1985', '31 Years', ' 11 months 4 days', 'Madhya Pradesh', 'Ujjain', 'Married', '5', 'A -ve', 'Male', '', '', '', '(op)_4.5', 'Executive', 'CMD Office', 'CMD Office', 'SMC', 'MMC', 'JMC', 'Kutch-II', 'Corporate', 'Sewree Operations', '10002957', 'Vidyadhar Parab', 'Rohan M', 'vinoo.dias@vvfltd.com', 'Mohit Sharma', 'vinoo.dias@vvfltd.com', '', '', '', '', '', 'IcIcI', '05-04-2010', '3.9', '7 Years', '10 Years', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Corporate', 'Baddi', 'Sion', 'Tiljala', 'Human Resources', 'Engineering Services', '', '', '', '', '', '', '', 'Resign', '300', ' IT', 'Active', '59ce2902a582a', '7894561230', 'VVF Ltd.', 'Vaibhav.s@gmail.com'),
('Bhavik', 'Kalai', 67, 'R', 'kalai@gmail.com', 'Hubli-dharwad border', '421510', 'Fire & safety', '', 'CDRPK3480Q', '932124103391', '03-03-1988', '29 Years', ' 10 months 17 days', 'Madhya Pradesh', 'Ratlam', 'Married', '3', 'AB +ve', 'Male', '', '', '', 'bk', 'Joint Managing Director', 'Environment, Health & Safety', 'Excise', 'Corporate Shared Services', 'JMC', 'SMC', 'Sion', 'Baddi', 'CMB Non Mfg', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '59cb3e0db3d76', '5849620096', 'VVF India Ltd.', 'bhavikk@ymail.com'),
('Vinod', 'Kangude', 72, 'P', 'vinod@vvfltd.com', 'Aurangabad', '458963', '12th', '', 'GBHYU8907E', '789456123085', '07-02-1985', '32 Years', ' 7 months 19 days', 'Telangana', 'Mahbubnagar', 'Single', '4', 'A +ve', 'Male', '', '', '', '', '', '', '', '', '', '', 'Corporate', '', '', '10002744', 'Amit Sanas', 'Manish', 'ravi.shankar@vvfltd.com', 'Mohit Sharma', 'rajesh.dighe@vvfltd.com', '', '', '', '', '', '', '16-06-2015', '', '2 Years', '2 Years', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '59ccaeb867faf', '9876543210', 'VVF India Ltd.', 'vinod@gmail.com'),
('Ankita', 'Joshi', 75, '', 'ankita.joshi@vvf.com', 'Panvel', '852369', 'BSC', 'MCA', 'ASDFG5678A', '852369741321', '05-04-1988', '29 Years', ' 5 months 23 days', 'Maharashtra', 'Mumbai', 'Married', '2', 'O +ve', 'Female', '', '', '', '852', 'Senior Manager', 'Excise', 'Excise', 'Oleochemicals', 'JMC', 'MMC', 'Corporate', 'Kutch-II', 'CPD', '10002744', 'Amit Sanas', 'Amit Sanas', 'vinoo.dias@vvfltd.com', 'Mohit Sharma', 'vinoo.dias@vvfltd.com', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '59ccaafaf27c4', '9865321245', 'VVF Ltd.', 'ankita.joshi@gmail.com'),
('Sandeep', 'Raut', 76, 'Hemant', 'sandy@vvf.com', 'Diva', '251445', 'Graduate', '', 'GTRJO7496T', '562039654125', '24-11-1991', '25 Years', ' 10 months 4 days', 'Uttar Pradesh', 'Mathura', 'Married', '3', 'A +ve', 'Male', '', '', '', '2345', 'Associate Vice President', 'Excise', 'Excise', 'Contract Manufacturing', 'JMC', 'SMC', 'Corporate', 'Corporate', 'PCP Quality', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '200', ' Finance', 'Active', '59cc90fc68936', '9563214520', 'VVF India Ltd.', 'sandeepraje@gmail.com'),
('Aakash', 'Karde', 77, 'Prakash', 'akash@vvfltd.com', 'Kansai Gaon, Ambernath(E)', '496301', 'Bcom', '', 'DFRTK7689R', '985634107745', '05-06-1992', '25 Years', ' 3 months 23 days', 'Tamil Nadu', 'Ranipet', 'Married', '1', 'A -ve', 'Male', '', '', '', 'A_K(20)', 'Director & President', 'Sales & Marketing', 'Sewree Operation', 'Contract Manufacturing', 'JMC', 'SMC', 'Corporate', 'Sion', 'Oleo Mfg', '10002744', 'Amit Sanas', 'Deepak', 'deepak.n.shah@vvfltd.com', 'Rohit Sharma', 'vinoo.dias@vvfltd.com', '', '', '', '', '', 'Suparna', '13-06-2013', '2.3', '4 Years', '4 Years', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '09-Apr-2021', '10', '10-Feb-2028', 'personal reason', 'exit', '', 'Resign', '300', ' IT', 'Active', '59ccc74e5b70c', '9527394885', 'VVF Ltd.', 'akash.k@gmail.com'),
('RaviKumar', 'Samarth', 98, '', 'ravi@123.co', 'Bijapur', '210001', 'schoolings', '', 'JKLHG7410I', '125112008520', '1983-09-21', 'NaN Years', ' NaN months NaN days', 'Karnataka', 'Vijayapura', 'Married', '4', 'A -ve', 'Male', 'ranji', '499', '', '99.99', 'General Manager', 'Strategic Procurement', 'CMD Office', 'Consumer Products Division', 'SMC', 'EG', 'Kolkata', 'Taloja', 'PCP Quality', '10002522', 'Charles Carvalho', 'Charles Carvalho', 'rayomand.mirzan@vvfltd.com', 'Amit Sanas', 'pravin.santhoor@vvfltd.com', '', '', '', '', '', 'Hexaware Technologies', '2014-07-30', '2', 'NaN Years', 'NaN Years', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Taloja', 'Kolkata', 'Baddi', 'Kutch-II', 'Human Resources', 'EXIM', '', '01-Dec-2033', '15', '02-Nov-2022', 'new job', 'open', '', 'Resign', '9919906999', ' CORPORATE-LEGAL & SECRETARIAL', 'Left', '59faf8038ea00', '0251260127', 'VVF Ltd.', 'ravi.s@yahoo.com'),
('Mayank', 'Agarwal', 103, '', 'mayank@vvf.com', 'Bangalore', '475102', 'bcom', '', 'FRGBT7520L', '852096307410', '01-01-1991', '26 Years', ' 10 months 2 days', 'Karnataka', 'Bengaluru', 'Married', '0', 'AB +ve', 'Male', '', '6aw100', '', '1991', 'Director & President', 'Research & Development', 'Quality Control', 'Personal Care Products', 'JMC', 'MMC', 'Corporate', 'Tiljala', 'SMC Cluster', '10002522', 'Charles Carvalho', 'Charles Carvalho', 'abhay.bhudolia@vvfltd.com', 'Amit Sanas', 'abhay.bhudolia@vvfltd.com', '', '', '', '', '', '', '2015-06-05', '', 'NaN Years', 'NaN Years', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Sion', 'Raipur', 'Kolkata', 'Kutch-II', 'Sales', 'Land & Properties', '01-01-2051', '', '', '', '', '', '', '', '', '', '', '59fc065c81f9e', '7539510000', 'VVF Ltd.', 'mayank.ag@outlook.com'),
('amogh', 'lanke', 104, 'rajendra', 'amoghl@vvfltd.com', 'Cur: Bangalore\nPerm: Ambernath (E)', '996615', 'B.E CSE', '', 'HYGBJ7530U', '465415415641', '07-06-1992', '25 Years', ' 4 months 27 days', 'Tamil Nadu', 'Chennai', 'Married', '1', 'AB -ve', 'Male', '', '', '', 'al(07)', 'Deputy', 'Information Technology', 'Engineering Services', 'SMC', 'JMC', 'MMC', 'Chennai', 'Corporate', 'Finance / IT / Indirect Tax/Excise/EXIM', '10002957', 'Vidyadhar Parab', 'Rajeev R', 'abhay.bhudolia@vvfltd.com', 'Mohit Sharma', 'abhay.bhudolia@vvfltd.com', 'EMT', 'Engineering Services', '01-Feb-2013', '01-Jun-2015', 'Asst Engineer', '', '08-02-2015', '', '2 Years', '2 Years', '01-01-2011', '01-Jun-2015', '01-07-2011', '01-Dec-2014', '20-Nov-2014', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Quality Assurance', 'Human Resources', '07-06-2052', '', '120', '30-Jun-2028', 'rertrt', 'trrty', 'rty', 'Retire', '', ' IT', 'Left', '59d5cfb1ca711', '9420270312', 'VVF India Ltd.', 'lanke.amogh@yahoo.co.in'),
('Manish', 'Gudekar', 106, '', 'manish.gudekar@vvf.com', 'Thane,kopari', '986532', 'B.Com', '', 'DDDDD5678F', '852369741321', '13-03-1990', '27 Years', ' 10 months 4 days', 'Maharashtra', 'Mumbai', 'Single', '3', 'AB +ve', 'Male', '', '', '', '121', 'Assistant Manager', 'Research & Development', 'Sewree Operation', 'Contract Manufacturing', 'SMC', 'MMC', 'Taloja', 'Raipur', 'PCP Quality', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'NaN Years', 'NaN Years', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '13-03-2050', '', '', '', '', '', '', '', '', '', '', '59cb4df6b472c', '9865321245', 'VVF India Ltd.', 'manish.gudekar@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Employee_master2`
--
ALTER TABLE `Employee_master2`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Employee_master2`
--
ALTER TABLE `Employee_master2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
