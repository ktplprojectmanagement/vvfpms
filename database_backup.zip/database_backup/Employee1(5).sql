-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 21, 2018 at 04:40 AM
-- Server version: 5.5.57
-- PHP Version: 7.0.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vvf_pmsstructure`
--

-- --------------------------------------------------------

--
-- Table structure for table `Employee1`
--

CREATE TABLE `Employee1` (
  `Employee_id` varchar(100) NOT NULL,
  `Employee_atd_code` varchar(100) NOT NULL,
  `Emp_fname` varchar(50) NOT NULL,
  `Emp_mname` varchar(50) NOT NULL,
  `Emp_lname` varchar(50) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `DOB` varchar(50) NOT NULL,
  `Nationality` varchar(20) NOT NULL,
  `Email_id` varchar(50) NOT NULL,
  `mobile_number` varchar(45) NOT NULL,
  `PAN_number` varchar(25) NOT NULL,
  `Designation` varchar(50) NOT NULL,
  `Cadre` varchar(25) NOT NULL,
  `Reporting_officer1_id` varchar(100) NOT NULL,
  `Reporting_officer2_id` varchar(100) NOT NULL,
  `Employee_status` varchar(25) NOT NULL,
  `Present_address` varchar(200) NOT NULL,
  `Permanent_address` varchar(200) NOT NULL,
  `Blood_group` varchar(25) NOT NULL,
  `Department` varchar(100) NOT NULL,
  `joining_date` varchar(50) NOT NULL,
  `cluster_appraiser` varchar(200) NOT NULL,
  `cluster_name` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `other_city` varchar(100) NOT NULL,
  `Image` varchar(300) NOT NULL,
  `changes_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `invalid_email` int(11) NOT NULL,
  `company_location` varchar(100) NOT NULL,
  `BU` varchar(1000) NOT NULL,
  `pms_status` varchar(100) NOT NULL,
  `reporting_1_change` varchar(300) NOT NULL,
  `reporting_2_change` varchar(300) NOT NULL,
  `reporting_1_effective_date` varchar(100) NOT NULL,
  `reporting_2_effective_date` varchar(100) NOT NULL,
  `bu_head_name` varchar(100) NOT NULL,
  `bu_head_email` varchar(100) NOT NULL,
  `plant_head_name` varchar(100) NOT NULL,
  `plant_head_email` varchar(100) NOT NULL,
  `new_kra_till_date` varchar(100) NOT NULL,
  `new_kra_create` varchar(100) NOT NULL,
  `year_end_review_of_manager` varchar(100) NOT NULL,
  `year_end_review_of_clshead` varchar(100) NOT NULL,
  `year_end_review_of_plant_head` varchar(100) NOT NULL,
  `year_end_review_of_bu_head` varchar(100) NOT NULL,
  `effective_date_promo` varchar(100) NOT NULL,
  `effective_date_norm` varchar(100) NOT NULL,
  `retire_date` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Employee1`
--

INSERT INTO `Employee1` (`Employee_id`, `Employee_atd_code`, `Emp_fname`, `Emp_mname`, `Emp_lname`, `Gender`, `DOB`, `Nationality`, `Email_id`, `mobile_number`, `PAN_number`, `Designation`, `Cadre`, `Reporting_officer1_id`, `Reporting_officer2_id`, `Employee_status`, `Present_address`, `Permanent_address`, `Blood_group`, `Department`, `joining_date`, `cluster_appraiser`, `cluster_name`, `state`, `city`, `other_city`, `Image`, `changes_date`, `invalid_email`, `company_location`, `BU`, `pms_status`, `reporting_1_change`, `reporting_2_change`, `reporting_1_effective_date`, `reporting_2_effective_date`, `bu_head_name`, `bu_head_email`, `plant_head_name`, `plant_head_email`, `new_kra_till_date`, `new_kra_create`, `year_end_review_of_manager`, `year_end_review_of_clshead`, `year_end_review_of_plant_head`, `year_end_review_of_bu_head`, `effective_date_promo`, `effective_date_norm`, `retire_date`) VALUES
('5c3d49', '5c3d49', 'Monica', '', 'Sadafule', '', '#N/A', 'Indian', 'employee.kritva@gmail.com', '1111111111', '#N/A', 'Assistant Manager', 'MMC', 'amit.sanas@vvfltd.com', '', 'Active', 'ASDSA', 'DSADSA', 'o', '', '#N/A', '', '', '', '', '', '', '2017-04-12 12:07:21', 0, 'Taloja', 'Oleochemicals', 'Inactive', 'employee.kritva@gmail.com', 'amit.sanas@vvfltd.com', '', '', '', 'amit.sanas@vvfltd.com', '', '', '', '', 'amit.sanas@vvfltd.com', '', '', '', '', '', '03-Mar-18'),
('10003836', '10003836', 'Manas', '', 'Kawale', 'undefined', '09-Oct-88', 'Indian', 'manas.kawale@vvfltd.com', '', 'CGMPK4977J', 'Executive', 'JMC', 'prasad.kale@vvfltd.com', '', 'undefined', '', '', '', 'Utility', '07-Jul-16', 'vilas.kakade@vvfltd.com', 'Oleo Mfg', '', '', '', '', '2017-07-26 09:21:49', 0, 'Taloja', 'Oleochemicals', 'Active', '', '', '1970-01-01', '-0001-11-30', '', 'ramesh.doraiswami@vvfltd.com', '', 'vilas.kakade@vvfltd.com', '', '', '', '', '', '', '', '', '0'),
('10002167', '10002167', 'HITESH', '', 'PATEL', 'Male', '1984-06-04', 'Indian', 'hitesh.qc@vvfltd.com', '9687027544', 'BLDPP3830L', 'Junior Executive', 'JMC', 'indresh.kumar@vvfltd.com', '', 'Active', 'Pardi', 'Pardi', '', 'Quality Assurance', '16-May-05', 'sudhakar.d@vvfltd.com', 'PCP Quality', '', '', '', '', '2017-07-12 10:10:24', 0, 'Daman', 'Personal Care Products', 'Active', '', '', '1970-01-01', '-0001-11-30', '', 'pratyaya.chakrabarti@vvfltd.com', '', 'dinesh.kabra@vvfltd.com', '', '', '', '', '', '', '', '', '0'),
('10002162', '10002162', 'Hitesh', '', 'Patel', 'undefined', '7-Jun-81', 'Indian', 'hiteshb.patel@vvfltd.com', '', 'AVMPP5767C', 'Jr. Executive\r\n', 'JMC', 'sharad.dahake@vvfltd.com', '', 'Active', 'At & Po-Rampore,Tal-Pardi,Dist-Valsad, Gujarat 396195', 'At & Po-Rampore,Tal-Pardi,Dist-Valsad, Gujarat 396195', 'AB-', 'Production', '10-Jul-04', 'sunil.singh@vvfltd.com', 'CMB Manufacturing', '', '', '', '', '2017-07-12 10:12:03', 0, 'Daman', 'Contract Manufacturing', 'Active', '', '', '1970-01-01', '-0001-11-30', '', 'pratyaya.chakrabarti@vvfltd.com', '', 'dinesh.kabra@vvfltd.com', '', '', '', '', '', '', '', '', '0'),
('1002', '1002', 'Rohit', '', 'Wagh', 'Male', '20-Apr-1992', 'Indian', 'kritvatech@outlook.com', '9865320147', 'ROHIT2004W', 'General Manager', 'JMC', 'employee.kritva@gmail.com', '', 'Active', 'Pune', 'Pune', 'A+', 'Information Technology', '01-Aug-2017', 'employee.kritva@gmail.com', 'Finance / IT / Indirect Tax/Excise/EXIM', '', '', '', '', '2017-10-13 11:58:38', 0, 'Corporate', 'Corporate Shared Services', 'Active', 'demo.appraisel@gmail.com', 'demo.appraisel@gmail.com', '1970-01-01', '2017-09-04', '', 'vadiraj.ekkundi@vvfltd.com', '', 'employee.kritva@gmail.com', '', '', '', '', '', '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Employee1`
--
ALTER TABLE `Employee1`
  ADD PRIMARY KEY (`Employee_id`),
  ADD UNIQUE KEY `Employee1` (`Employee_id`),
  ADD UNIQUE KEY `emp_index` (`Employee_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
